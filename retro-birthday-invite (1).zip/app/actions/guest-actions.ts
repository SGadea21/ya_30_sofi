"use server"

import { isSupabaseConfigured } from "@/lib/supabase"

export async function submitGuestRSVP(formData: FormData) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      return {
        success: false,
        message: "Base de datos no configurada. Contacta al administrador.",
      }
    }

    const firstName = formData.get("firstName") as string
    const lastName = formData.get("lastName") as string
    const hasCompanion = formData.get("hasCompanion") === "true"
    const companionName = formData.get("companionName") as string

    // Validaciones
    if (!firstName || !lastName) {
      return {
        success: false,
        message: "Nombre y apellido son obligatorios",
      }
    }

    if (hasCompanion && !companionName) {
      return {
        success: false,
        message: "El nombre del acompañante es obligatorio",
      }
    }

    // For demo purposes, return success without database operation
    return {
      success: true,
      message: `¡Gracias ${firstName}! Tu asistencia ha sido confirmada. (Demo mode - configura Supabase para funcionalidad completa)`,
      data: { first_name: firstName, last_name: lastName, has_companion: hasCompanion, companion_name: companionName },
    }
  } catch (error) {
    console.error("Server error:", error)
    return {
      success: false,
      message: "Error del servidor. Intenta nuevamente.",
    }
  }
}

export async function addSongToPlaylist(formData: FormData) {
  try {
    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      // Import supabase here to avoid the error
      const { supabase } = await import("@/lib/supabase")

      const songTitle = formData.get("songTitle") as string
      const artist = formData.get("artist") as string
      const spotifyUrl = formData.get("spotifyUrl") as string

      // Validaciones
      if (!songTitle || !artist) {
        return {
          success: false,
          message: "Título de la canción y artista son obligatorios",
        }
      }

      // Insertar en la base de datos
      const { data, error } = await supabase
        .from("songs")
        .insert([
          {
            song_title: songTitle,
            artist: artist,
            spotify_url: spotifyUrl || null,
          },
        ])
        .select()

      if (error) {
        console.error("Error inserting song:", error)
        return {
          success: false,
          message: "Error al agregar canción. Intenta nuevamente.",
        }
      }

      return {
        success: true,
        message: `¡Canción "${songTitle}" agregada exitosamente!`,
        data: data[0],
      }
    }

    // Demo mode fallback
    const songTitle = formData.get("songTitle") as string
    const artist = formData.get("artist") as string

    if (!songTitle || !artist) {
      return {
        success: false,
        message: "Título de la canción y artista son obligatorios",
      }
    }

    return {
      success: true,
      message: `¡Canción "${songTitle}" agregada exitosamente! (Demo mode - configura Supabase para funcionalidad completa)`,
      data: { song_title: songTitle, artist: artist },
    }
  } catch (error) {
    console.error("Server error:", error)
    return {
      success: false,
      message: "Error del servidor. Intenta nuevamente.",
    }
  }
}
