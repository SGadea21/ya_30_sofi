import { supabase, isSupabaseConfigured } from "@/lib/supabase"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Music, Users, User, AlertTriangle } from "lucide-react"

export default async function AdminPage() {
  // Check if Supabase is configured
  if (!isSupabaseConfigured()) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-cyan-400 p-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-6xl font-black text-white mb-4 drop-shadow-lg">🔧 CONFIGURACIÓN REQUERIDA</h1>
          </div>

          <Card className="bg-white border-4 border-black shadow-lg max-w-2xl mx-auto">
            <CardContent className="p-8 text-center">
              <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-orange-500" />
              <h2 className="text-2xl font-black text-black mb-4">Supabase No Configurado</h2>
              <p className="text-lg text-gray-700 mb-6">
                Para ver el panel de administración, necesitas configurar Supabase primero.
              </p>

              <div className="bg-gray-100 p-4 rounded-lg text-left mb-6">
                <h3 className="font-bold text-black mb-2">Pasos para configurar:</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700">
                  <li>
                    Crea una cuenta gratuita en{" "}
                    <a href="https://supabase.com" target="_blank" className="text-blue-600 underline" rel="noreferrer">
                      supabase.com
                    </a>
                  </li>
                  <li>Crea un nuevo proyecto</li>
                  <li>Ve a Settings → API</li>
                  <li>Copia la URL y la clave anónima</li>
                  <li>Configura las variables de entorno en Vercel</li>
                </ol>
              </div>

              <a
                href="/"
                className="inline-block bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black text-xl py-4 px-8 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform hover:translate-x-1 hover:translate-y-1 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all rounded-lg"
              >
                ← VOLVER A LA INVITACIÓN
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Try to fetch data, but handle errors gracefully
  let guests = []
  let songs = []
  let guestsError = null
  let songsError = null

  try {
    const { data: guestsData, error: guestsErr } = await supabase
      .from("guests")
      .select("*")
      .order("created_at", { ascending: false })

    guests = guestsData || []
    guestsError = guestsErr
  } catch (error) {
    guestsError = error
  }

  try {
    const { data: songsData, error: songsErr } = await supabase
      .from("songs")
      .select("*")
      .order("created_at", { ascending: false })

    songs = songsData || []
    songsError = songsErr
  } catch (error) {
    songsError = error
  }

  // Calculate statistics
  const totalGuests = guests?.length || 0
  const totalWithCompanions = guests?.filter((g) => g.has_companion).length || 0
  const totalAttendees = totalGuests + totalWithCompanions
  const totalSongs = songs?.length || 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-cyan-400 p-8">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-6xl font-black text-white mb-4 drop-shadow-lg">🎉 PANEL ADMIN 🎉</h1>
          <p className="text-2xl font-bold text-white">Dashboard de tu Fiesta Retro 2005-2013</p>
        </div>

        {/* Statistics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-green-400 to-emerald-500 border-4 border-black shadow-lg">
            <CardContent className="p-6 text-center">
              <Users className="w-12 h-12 mx-auto mb-2 text-white" />
              <h3 className="text-2xl font-black text-white">{totalGuests}</h3>
              <p className="font-bold text-white">Confirmados</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-blue-400 to-cyan-500 border-4 border-black shadow-lg">
            <CardContent className="p-6 text-center">
              <User className="w-12 h-12 mx-auto mb-2 text-white" />
              <h3 className="text-2xl font-black text-white">{totalAttendees}</h3>
              <p className="font-bold text-white">Total Asistentes</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-400 to-pink-500 border-4 border-black shadow-lg">
            <CardContent className="p-6 text-center">
              <Music className="w-12 h-12 mx-auto mb-2 text-white" />
              <h3 className="text-2xl font-black text-white">{totalSongs}</h3>
              <p className="font-bold text-white">Canciones</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-400 to-red-500 border-4 border-black shadow-lg">
            <CardContent className="p-6 text-center">
              <Calendar className="w-12 h-12 mx-auto mb-2 text-white" />
              <h3 className="text-2xl font-black text-white">15</h3>
              <p className="font-bold text-white">Días Restantes</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Guest List */}
          <Card className="bg-white border-4 border-black shadow-lg">
            <CardContent className="p-6">
              <h2 className="text-3xl font-black text-black mb-6 text-center">👥 LISTA DE INVITADOS</h2>

              {guestsError ? (
                <div className="text-center p-4 bg-yellow-100 rounded-lg border-2 border-yellow-400">
                  <p className="text-yellow-800 font-semibold">
                    Error al cargar invitados. Verifica la configuración de Supabase.
                  </p>
                </div>
              ) : guests && guests.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {guests.map((guest, index) => (
                    <div
                      key={guest.id}
                      className="bg-gradient-to-r from-cyan-100 to-blue-100 p-4 rounded-lg border-2 border-black"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-black text-lg text-black">
                            {index + 1}. {guest.first_name} {guest.last_name}
                          </h3>
                          {guest.has_companion && (
                            <p className="text-sm font-semibold text-gray-700">+ Acompañante: {guest.companion_name}</p>
                          )}
                          <p className="text-xs text-gray-600">
                            Confirmado:{" "}
                            {guest.created_at
                              ? new Date(guest.created_at).toLocaleDateString("es-ES")
                              : "Fecha no disponible"}
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                            {guest.has_companion ? "2 personas" : "1 persona"}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-600">No hay invitados confirmados aún</p>
              )}
            </CardContent>
          </Card>

          {/* Songs List */}
          <Card className="bg-white border-4 border-black shadow-lg">
            <CardContent className="p-6">
              <h2 className="text-3xl font-black text-black mb-6 text-center">🎵 PLAYLIST SUGERIDA</h2>

              {songsError ? (
                <div className="text-center p-4 bg-yellow-100 rounded-lg border-2 border-yellow-400">
                  <p className="text-yellow-800 font-semibold">
                    Error al cargar canciones. Verifica la configuración de Supabase.
                  </p>
                </div>
              ) : songs && songs.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {songs.map((song, index) => (
                    <div
                      key={song.id}
                      className="bg-gradient-to-r from-purple-100 to-pink-100 p-4 rounded-lg border-2 border-black"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h3 className="font-black text-lg text-black">
                            {index + 1}. {song.song_title}
                          </h3>
                          <p className="font-semibold text-gray-700 text-lg">{song.artist}</p>
                          {song.spotify_url && (
                            <a
                              href={song.spotify_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-green-600 text-sm hover:underline mt-2 font-semibold"
                            >
                              🎧 Escuchar en Spotify
                            </a>
                          )}
                          <p className="text-xs text-gray-600 mt-1">
                            Agregada:{" "}
                            {song.created_at
                              ? new Date(song.created_at).toLocaleDateString("es-ES")
                              : "Fecha no disponible"}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-600">No hay canciones sugeridas aún</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Back button */}
        <div className="text-center mt-8">
          <a
            href="/"
            className="inline-block bg-gradient-to-r from-pink-500 to-purple-600 text-white font-black text-xl py-4 px-8 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform hover:translate-x-1 hover:translate-y-1 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all rounded-lg"
          >
            ← VOLVER A LA INVITACIÓN
          </a>
        </div>
      </div>
    </div>
  )
}
