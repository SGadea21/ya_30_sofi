"use client"

import type React from "react"
import { CartoonLoader } from "@/components/ui/cartoon-loader" // Import CartoonLoader
import { MusicHitsSection } from "@/components/music-hits-section"
import { SongSuggestionForm } from "@/components/song-suggestion-form"
import { submitGuestRSVP } from "@/app/actions/guest-actions"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar, Clock, MapPin, Sparkles, Star, Zap } from "lucide-react"

export default function RetroPartyInvite() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    hasCompanion: false,
    companionName: "",
  })
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitted(true)
    // Aquí puedes agregar la lógica para enviar los datos
    console.log("RSVP Data:", formData)
  }

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 4000) // 4 segundos de loader

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return <CartoonLoader />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-cyan-400 relative overflow-hidden">
      {/* Elementos decorativos flotantes */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-10 left-10 w-8 h-8 bg-yellow-300 rounded-full animate-bounce"
          style={{ animationDelay: "0s" }}
        />
        <div
          className="absolute top-20 right-20 w-6 h-6 bg-lime-300 rounded-full animate-bounce"
          style={{ animationDelay: "1s" }}
        />
        <div
          className="absolute bottom-20 left-20 w-10 h-10 bg-orange-300 rounded-full animate-bounce"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute bottom-10 right-10 w-7 h-7 bg-pink-300 rounded-full animate-bounce"
          style={{ animationDelay: "0.5s" }}
        />
        <Star
          className="absolute top-1/4 left-1/4 w-12 h-12 text-yellow-300 animate-spin"
          style={{ animationDuration: "8s" }}
        />
        <Sparkles className="absolute top-1/3 right-1/3 w-10 h-10 text-cyan-300 animate-pulse" />
        <Zap className="absolute bottom-1/3 left-1/2 w-8 h-8 text-yellow-400 animate-bounce" />
      </div>

      <div className="container mx-auto px-4 py-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-pink-300 to-cyan-300 mb-4 transform -rotate-2 drop-shadow-lg">
            ¡CUMPLE 30!
          </h1>
          <div className="bg-black text-white px-8 py-4 transform rotate-1 inline-block border-4 border-white shadow-lg">
            <h2 className="text-2xl md:text-3xl font-bold">FIESTA RETRO 2005-2013</h2>
          </div>
          <p className="text-xl md:text-2xl font-bold text-white mt-6 drop-shadow-lg">
            ¡Celebremos mis 30 con los hits que marcaron nuestra adolescencia! 🎉
          </p>
        </div>

        {/* Event Details */}
        <Card className="mb-8 bg-gradient-to-r from-lime-300 to-yellow-300 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform -rotate-1">
          <CardContent className="p-8">
            <h3 className="text-3xl font-black text-black mb-6 text-center">📅 DETALLES DEL EVENTO 📅</h3>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-white p-4 rounded-lg border-2 border-black shadow-md">
                  <Calendar className="w-6 h-6 text-purple-600" />
                  <div>
                    <p className="font-bold text-black">FECHA:</p>
                    <p className="text-lg font-semibold text-purple-600">Sábado 15 de Febrero, 2025</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white p-4 rounded-lg border-2 border-black shadow-md">
                  <Clock className="w-6 h-6 text-pink-600" />
                  <div>
                    <p className="font-bold text-black">HORA:</p>
                    <p className="text-lg font-semibold text-pink-600">21:00 hs - Hasta que el cuerpo aguante</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white p-4 rounded-lg border-2 border-black shadow-md">
                  <MapPin className="w-6 h-6 text-cyan-600" />
                  <div>
                    <p className="font-bold text-black">LUGAR:</p>
                    <p className="text-lg font-semibold text-cyan-600">Mi Casa - Calle Nostalgia 1999</p>
                    <p className="text-sm text-gray-600">Ciudad Retro, Provincia</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 rounded-lg border-2 border-black shadow-md text-white">
                  <h4 className="font-bold text-xl mb-2">👗 CÓDIGO DE VESTIMENTA:</h4>
                  <p className="font-semibold">¡OUTFIT RETRO OBLIGATORIO!</p>
                  <ul className="text-sm mt-2 space-y-1">
                    <li>• Jeans skinny o pitillos</li>
                    <li>• Remeras ajustadas y tops</li>
                    <li>• Zapatillas Converse o Vans</li>
                    <li>• Accesorios brillantes y cadenas</li>
                    <li>• Estilo emo/scene opcional</li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-orange-400 to-red-400 p-4 rounded-lg border-2 border-black shadow-md text-white">
                  <h4 className="font-bold text-xl mb-2">🎵 MÚSICA:</h4>
                  <p className="font-semibold">Hits 2005-2013</p>
                  <p className="text-sm mt-1">Reggaeton, Electro-Pop, Rock, Hip Hop, ¡y más!</p>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-black text-white p-4 rounded-lg border-2 border-white">
              <h4 className="font-bold text-xl mb-2 text-center">🍕 ¿QUÉ HABRÁ? 🍕</h4>
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <p className="font-semibold">COMIDA:</p>
                  <p className="text-sm">Pizza, snacks retro, y sorpresas</p>
                </div>
                <div>
                  <p className="font-semibold">BEBIDAS:</p>
                  <p className="text-sm">Tragos coloridos y refrescos</p>
                </div>
                <div>
                  <p className="font-semibold">DIVERSIÓN:</p>
                  <p className="text-sm">Karaoke, juegos, y mucha nostalgia</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Music Hits Section */}
        <MusicHitsSection />

        <div className="grid md:grid-cols-2 gap-8">
          {/* RSVP Form */}
          <Card className="bg-gradient-to-br from-cyan-300 to-blue-400 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform rotate-1">
            <CardContent className="p-8">
              <h3 className="text-3xl font-black text-black mb-6 text-center">✨ CONFIRMA TU ASISTENCIA ✨</h3>

              {!isSubmitted ? (
                <form action={submitGuestRSVP} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName" className="text-lg font-bold text-black">
                      NOMBRE:
                    </Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                      className="border-4 border-black text-lg font-semibold bg-white"
                      placeholder="Tu nombre"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="lastName" className="text-lg font-bold text-black">
                      APELLIDO:
                    </Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                      className="border-4 border-black text-lg font-semibold bg-white"
                      placeholder="Tu apellido"
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-3 bg-white p-4 rounded-lg border-2 border-black">
                    <Checkbox
                      id="companion"
                      checked={formData.hasCompanion}
                      onCheckedChange={(checked) => handleInputChange("hasCompanion", checked as boolean)}
                      className="border-2 border-black"
                    />
                    <Label htmlFor="companion" className="text-lg font-bold text-black cursor-pointer">
                      ¿Vienes con acompañante?
                    </Label>
                  </div>

                  {formData.hasCompanion && (
                    <div className="space-y-2">
                      <Label htmlFor="companionName" className="text-lg font-bold text-black">
                        NOMBRE DEL ACOMPAÑANTE:
                      </Label>
                      <Input
                        id="companionName"
                        value={formData.companionName}
                        onChange={(e) => handleInputChange("companionName", e.target.value)}
                        className="border-4 border-black text-lg font-semibold bg-white"
                        placeholder="Nombre de tu acompañante"
                        required={formData.hasCompanion}
                      />
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-black text-xl py-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform hover:translate-x-1 hover:translate-y-1 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all"
                  >
                    ¡CONFIRMAR ASISTENCIA! 🎉
                  </Button>
                </form>
              ) : (
                <div className="text-center space-y-4">
                  <div className="text-6xl">🎉</div>
                  <h4 className="text-2xl font-black text-black">¡CONFIRMADO!</h4>
                  <p className="text-lg font-semibold text-black">
                    ¡Gracias {formData.firstName}! Te esperamos para la fiesta más retro del año.
                  </p>
                  {formData.hasCompanion && (
                    <p className="text-lg font-semibold text-black">
                      {formData.companionName} también está invitado/a. ¡Genial!
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Spotify Playlist */}
          <SongSuggestionForm />
        </div>

        {/* Footer */}
        <div className="text-center mt-12">
          <div className="bg-black text-white px-8 py-4 inline-block border-4 border-white shadow-lg transform rotate-1">
            <p className="text-lg font-bold">
              ¡No faltes! Será una noche inolvidable llena de nostalgia y diversión 🌟
            </p>
          </div>
          <p className="text-white font-semibold mt-4 text-lg drop-shadow-lg">
            Para consultas: WhatsApp +54 9 11 1234-5678
          </p>
          <p className="text-xl font-bold text-white mt-6 drop-shadow-lg">
            ¡Revivamos la época dorada de nuestra juventud! 🎉
          </p>
          <div className="mt-6">
            <a
              href="/admin"
              className="inline-block bg-black text-white font-bold py-2 px-4 border-2 border-white rounded hover:bg-gray-800 transition-colors"
            >
              🔐 Panel Admin
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
