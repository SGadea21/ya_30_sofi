"use client"

import { useEffect, useState } from "react"

export default function CartoonLoader() {
  const [currentText, setCurrentText] = useState(0)
  const [showStars, setShowStars] = useState(false)

  const loadingTexts = [
    "¡PREPARANDO LA FIESTA RETRO!",
    "CARGANDO NOSTALGIA...",
    "¡ACTIVANDO MODO 90s!",
    "¡CASI LISTOS PARA LA DIVERSIÓN!",
  ]

  useEffect(() => {
    const textInterval = setInterval(() => {
      setCurrentText((prev) => (prev + 1) % loadingTexts.length)
    }, 800)

    const starsTimeout = setTimeout(() => {
      setShowStars(true)
    }, 1000)

    return () => {
      clearInterval(textInterval)
      clearTimeout(starsTimeout)
    }
  }, [])

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-purple-600 via-pink-500 to-cyan-400 flex items-center justify-center overflow-hidden">
      {/* Fondo animado con formas geométricas */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Círculos flotantes estilo cartoon */}
        <div
          className="absolute top-10 left-10 w-16 h-16 bg-yellow-300 rounded-full animate-bounce border-4 border-black"
          style={{ animationDelay: "0s", animationDuration: "1.5s" }}
        />
        <div
          className="absolute top-20 right-20 w-12 h-12 bg-lime-300 rounded-full animate-bounce border-4 border-black"
          style={{ animationDelay: "0.3s", animationDuration: "1.8s" }}
        />
        <div
          className="absolute bottom-20 left-20 w-20 h-20 bg-orange-300 rounded-full animate-bounce border-4 border-black"
          style={{ animationDelay: "0.6s", animationDuration: "1.2s" }}
        />
        <div
          className="absolute bottom-10 right-10 w-14 h-14 bg-pink-300 rounded-full animate-bounce border-4 border-black"
          style={{ animationDelay: "0.9s", animationDuration: "1.6s" }}
        />

        {/* Formas geométricas estilo cartoon */}
        <div
          className="absolute top-1/4 left-1/4 w-8 h-8 bg-red-400 transform rotate-45 animate-spin border-4 border-black"
          style={{ animationDuration: "3s" }}
        />
        <div className="absolute top-1/3 right-1/3 w-0 h-0 border-l-8 border-r-8 border-b-16 border-l-transparent border-r-transparent border-b-green-400 animate-pulse border-4 border-black" />
        <div className="absolute bottom-1/3 left-1/2 w-12 h-6 bg-blue-400 animate-pulse border-4 border-black" />

        {/* Estrellas animadas */}
        {showStars && (
          <>
            <div className="absolute top-16 left-1/2 text-4xl animate-ping" style={{ animationDelay: "0s" }}>
              ⭐
            </div>
            <div className="absolute top-1/2 left-16 text-3xl animate-ping" style={{ animationDelay: "0.5s" }}>
              ✨
            </div>
            <div className="absolute bottom-16 right-1/2 text-4xl animate-ping" style={{ animationDelay: "1s" }}>
              🌟
            </div>
            <div className="absolute top-1/3 right-16 text-3xl animate-ping" style={{ animationDelay: "1.5s" }}>
              💫
            </div>
          </>
        )}
      </div>

      {/* Contenido principal del loader */}
      <div className="relative z-10 text-center">
        {/* Personaje principal estilo cartoon */}
        <div className="mb-8 relative">
          {/* Cuerpo del personaje */}
          <div className="relative mx-auto">
            {/* Cabeza */}
            <div className="w-32 h-32 bg-yellow-200 rounded-full border-8 border-black mx-auto mb-4 relative animate-bounce">
              {/* Ojos */}
              <div className="absolute top-6 left-6 w-6 h-6 bg-black rounded-full animate-pulse" />
              <div className="absolute top-6 right-6 w-6 h-6 bg-black rounded-full animate-pulse" />
              {/* Sonrisa */}
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-12 h-6 border-b-4 border-black rounded-full" />
              {/* Mejillas */}
              <div className="absolute top-12 left-2 w-4 h-4 bg-pink-300 rounded-full" />
              <div className="absolute top-12 right-2 w-4 h-4 bg-pink-300 rounded-full" />
            </div>

            {/* Cuerpo */}
            <div className="w-24 h-32 bg-red-400 border-8 border-black mx-auto rounded-lg relative">
              {/* Brazos */}
              <div className="absolute -left-8 top-4 w-6 h-16 bg-yellow-200 border-4 border-black rounded-full animate-pulse" />
              <div className="absolute -right-8 top-4 w-6 h-16 bg-yellow-200 border-4 border-black rounded-full animate-pulse" />
            </div>

            {/* Piernas */}
            <div className="flex justify-center gap-2 mt-2">
              <div
                className="w-6 h-16 bg-blue-400 border-4 border-black rounded-full animate-bounce"
                style={{ animationDelay: "0.2s" }}
              />
              <div
                className="w-6 h-16 bg-blue-400 border-4 border-black rounded-full animate-bounce"
                style={{ animationDelay: "0.4s" }}
              />
            </div>
          </div>
        </div>

        {/* Texto animado */}
        <div className="mb-8">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4 animate-pulse drop-shadow-lg">
            {loadingTexts[currentText]}
          </h1>

          {/* Barra de carga estilo cartoon */}
          <div className="w-80 h-8 bg-white border-4 border-black rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-gradient-to-r from-lime-400 via-yellow-400 to-orange-400 rounded-full animate-pulse loading-bar border-r-4 border-black" />
          </div>
        </div>

        {/* Elementos decorativos adicionales */}
        <div className="flex justify-center gap-4 mb-4">
          <div
            className="w-8 h-8 bg-purple-400 rounded-full border-4 border-black animate-bounce"
            style={{ animationDelay: "0s" }}
          />
          <div
            className="w-8 h-8 bg-green-400 rounded-full border-4 border-black animate-bounce"
            style={{ animationDelay: "0.2s" }}
          />
          <div
            className="w-8 h-8 bg-orange-400 rounded-full border-4 border-black animate-bounce"
            style={{ animationDelay: "0.4s" }}
          />
          <div
            className="w-8 h-8 bg-pink-400 rounded-full border-4 border-black animate-bounce"
            style={{ animationDelay: "0.6s" }}
          />
          <div
            className="w-8 h-8 bg-cyan-400 rounded-full border-4 border-black animate-bounce"
            style={{ animationDelay: "0.8s" }}
          />
        </div>

        {/* Texto adicional */}
        <p className="text-xl font-bold text-white animate-pulse drop-shadow-lg">¡Los 90s están volviendo! 🎉</p>
      </div>

      {/* Efectos de partículas */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              animationDuration: `${1 + Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <style jsx>{`
        .loading-bar {
          animation: loading 3s ease-in-out infinite;
        }
        
        @keyframes loading {
          0% { width: 0%; }
          50% { width: 70%; }
          100% { width: 100%; }
        }
      `}</style>
    </div>
  )
}
