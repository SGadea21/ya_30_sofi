"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Music, Disc } from "lucide-react"

export function MusicHitsSection() {
  const hitSongs = [
    { artist: "Daddy Yankee", song: "Gasolina", year: "2004" },
    { artist: "Lady Gaga", song: "Poker Face", year: "2008" },
    { artist: "Black Eyed Peas", song: "I Gotta Feeling", year: "2009" },
    { artist: "David Guetta", song: "Titanium", year: "2011" },
    { artist: "LMFAO", song: "Party Rock Anthem", year: "2011" },
    { artist: "Pitbull", song: "Give Me Everything", year: "2011" },
  ]

  const musicGenres = [
    { genre: "REGGAETON", icon: "🔥", description: "Daddy Yankee, Don Omar, Wisin & Yandel" },
    { genre: "ELECTRO-POP", icon: "⚡", description: "Lady Gaga, Katy Perry, Kesha" },
    { genre: "HIP HOP", icon: "🎤", description: "50 Cent, Eminem, Kanye West" },
    { genre: "ROCK ALT", icon: "🎸", description: "Linkin Park, Green Day, Paramore" },
    { genre: "DANCE", icon: "💃", description: "David Guetta, Swedish House Mafia" },
    { genre: "POP LATINO", icon: "🌟", description: "Jesse & Joy, Manu Chao, Shakira" },
  ]

  return (
    <Card className="mb-8 bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform rotate-1">
      <CardContent className="p-8">
        <h3 className="text-3xl font-black text-white mb-6 text-center drop-shadow-lg">
          🎵 HITS QUE NO PUEDEN FALTAR 🎵
        </h3>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Géneros musicales */}
          <div className="space-y-4">
            <h4 className="text-2xl font-bold text-white mb-4 text-center">GÉNEROS DE LA ÉPOCA</h4>
            {musicGenres.map((item, index) => (
              <div
                key={index}
                className="bg-white/90 backdrop-blur-sm p-4 rounded-lg border-2 border-black shadow-md transform hover:scale-105 transition-transform"
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{item.icon}</span>
                  <div>
                    <h5 className="font-black text-black text-lg">{item.genre}</h5>
                    <p className="text-sm text-gray-700 font-semibold">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Hits icónicos */}
          <div className="space-y-4">
            <h4 className="text-2xl font-bold text-white mb-4 text-center">HITS ICÓNICOS</h4>
            {hitSongs.map((hit, index) => (
              <div
                key={index}
                className="bg-gradient-to-r from-yellow-300 to-orange-300 p-4 rounded-lg border-2 border-black shadow-md transform hover:scale-105 transition-transform"
              >
                <div className="flex items-center gap-3">
                  <Disc className="w-6 h-6 text-black animate-spin" style={{ animationDuration: "3s" }} />
                  <div>
                    <p className="font-black text-black">{hit.song}</p>
                    <p className="text-sm font-semibold text-gray-800">
                      {hit.artist} ({hit.year})
                    </p>
                  </div>
                </div>
              </div>
            ))}

            <div className="bg-black text-white p-4 rounded-lg border-2 border-white text-center">
              <Music className="w-8 h-8 mx-auto mb-2 text-yellow-400" />
              <p className="font-bold">¡Y MUCHOS MÁS!</p>
              <p className="text-sm">Los hits que marcaron tu adolescencia</p>
            </div>
          </div>
        </div>

        {/* Sección especial de reggaeton */}
        <div className="mt-8 bg-gradient-to-r from-red-500 to-orange-500 p-6 rounded-lg border-4 border-black">
          <h4 className="text-2xl font-black text-white mb-4 text-center">🔥 ZONA REGGAETON 🔥</h4>
          <div className="grid md:grid-cols-3 gap-4 text-center">
            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg">
              <p className="font-bold text-white">ERA DORADA</p>
              <p className="text-sm text-yellow-200">2004-2012</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg">
              <p className="font-bold text-white">PERREO INTENSO</p>
              <p className="text-sm text-yellow-200">¡Obligatorio!</p>
            </div>
            <div className="bg-white/20 backdrop-blur-sm p-3 rounded-lg">
              <p className="font-bold text-white">DEMBOW</p>
              <p className="text-sm text-yellow-200">El ritmo que nos movía</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
