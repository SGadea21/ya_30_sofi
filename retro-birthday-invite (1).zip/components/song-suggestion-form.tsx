"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { addSongToPlaylist } from "@/app/actions/guest-actions"
import { Music } from "lucide-react"

export function SongSuggestionForm() {
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")

  const handleSubmit = async (formData: FormData) => {
    setIsLoading(true)
    const result = await addSongToPlaylist(formData)

    setMessage(result.message)
    if (result.success) {
      setIsSubmitted(true)
    }
    setIsLoading(false)
  }

  if (isSubmitted) {
    return (
      <Card className="bg-gradient-to-br from-green-300 to-emerald-400 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <CardContent className="p-8 text-center">
          <div className="text-6xl mb-4">🎵</div>
          <h4 className="text-2xl font-black text-black mb-4">¡CANCIÓN AGREGADA!</h4>
          <p className="text-lg font-semibold text-black">{message}</p>
          <Button
            onClick={() => {
              setIsSubmitted(false)
              setMessage("")
            }}
            className="mt-4 bg-black text-white border-2 border-white hover:bg-gray-800"
          >
            Agregar otra canción
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-purple-300 to-pink-400 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transform rotate-1">
      <CardContent className="p-8">
        <h3 className="text-3xl font-black text-black mb-6 text-center">🎵 SUGIERE UNA CANCIÓN 🎵</h3>

        <form action={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="songTitle" className="text-lg font-bold text-black">
              TÍTULO DE LA CANCIÓN: *
            </Label>
            <Input
              id="songTitle"
              name="songTitle"
              className="border-4 border-black text-lg font-semibold bg-white"
              placeholder="Ej: Gasolina"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="artist" className="text-lg font-bold text-black">
              ARTISTA: *
            </Label>
            <Input
              id="artist"
              name="artist"
              className="border-4 border-black text-lg font-semibold bg-white"
              placeholder="Ej: Daddy Yankee"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="spotifyUrl" className="text-lg font-bold text-black">
              LINK DE SPOTIFY (OPCIONAL):
            </Label>
            <Input
              id="spotifyUrl"
              name="spotifyUrl"
              type="url"
              className="border-4 border-black text-lg font-semibold bg-white"
              placeholder="https://open.spotify.com/track/..."
            />
            <p className="text-sm text-black/70 font-semibold">
              💡 Tip: Ve a Spotify, busca la canción, dale "Compartir" → "Copiar enlace"
            </p>
          </div>

          {message && (
            <div
              className={`p-4 rounded-lg border-2 border-black ${
                message.includes("Error") ? "bg-red-200 text-red-800" : "bg-green-200 text-green-800"
              }`}
            >
              <p className="font-semibold">{message}</p>
            </div>
          )}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white font-black text-xl py-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform hover:translate-x-1 hover:translate-y-1 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-50"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 animate-spin" />
                AGREGANDO...
              </div>
            ) : (
              "🎵 AGREGAR A LA PLAYLIST 🎵"
            )}
          </Button>
        </form>

        <div className="mt-6 bg-black text-white p-4 rounded-lg border-2 border-white">
          <h4 className="font-bold text-lg mb-2 text-center">🎯 GÉNEROS QUE BUSCAMOS</h4>
          <div className="flex flex-wrap gap-2 justify-center">
            {["Reggaeton", "Electro-Pop", "Hip Hop", "Rock", "Dance", "Pop Latino"].map((genre) => (
              <span
                key={genre}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-bold border-2 border-white"
              >
                {genre}
              </span>
            ))}
          </div>
          <p className="text-center text-sm mt-2 text-yellow-200">
            ¡Canciones de 2005-2013 que marcaron nuestra juventud!
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
