import { createClient } from "@supabase/supabase-js"

// Provide fallback values for development/preview
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://placeholder.supabase.co"
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "placeholder-key"

// Create client with error handling
export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Check if Supabase is properly configured
export const isSupabaseConfigured = () => {
  return process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
}

// Types for TypeScript
export interface Guest {
  id?: number
  first_name: string
  last_name: string
  has_companion: boolean
  companion_name?: string
  created_at?: string
  updated_at?: string
}

export interface Song {
  id?: number
  song_title: string
  artist: string
  year?: number
  genre?: string
  suggested_by?: string
  spotify_url?: string
  created_at?: string
}
