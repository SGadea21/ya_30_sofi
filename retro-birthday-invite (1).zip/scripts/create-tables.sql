-- Crear tabla de invitados
CREATE TABLE IF NOT EXISTS guests (
  id SERIAL PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  has_companion BOOLEAN DEFAULT FALSE,
  companion_name VARCHAR(100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Crear tabla de canciones
CREATE TABLE IF NOT EXISTS songs (
  id SERIAL PRIMARY KEY,
  song_title VARCHAR(200) NOT NULL,
  artist VARCHAR(200) NOT NULL,
  year INTEGER,
  genre VARCHAR(100),
  suggested_by VARCHAR(200),
  spotify_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Crear índices para mejor rendimiento
CREATE INDEX IF NOT EXISTS idx_guests_created_at ON guests(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_created_at ON songs(created_at);
CREATE INDEX IF NOT EXISTS idx_songs_genre ON songs(genre);
