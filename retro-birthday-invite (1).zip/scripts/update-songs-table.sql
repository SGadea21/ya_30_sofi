-- Actualizar la tabla de canciones para simplificar los campos
-- Hacer que year, genre y suggested_by sean opcionales o eliminarlos si no los necesitas

-- Si quieres mantener la tabla simple, puedes eliminar las columnas que no necesitas:
ALTER TABLE songs DROP COLUMN IF EXISTS year;
ALTER TABLE songs DROP COLUMN IF EXISTS genre;
ALTER TABLE songs DROP COLUMN IF EXISTS suggested_by;

-- O si prefieres mantenerlas pero hacerlas completamente opcionales, no necesitas hacer nada
-- ya que están definidas sin NOT NULL
